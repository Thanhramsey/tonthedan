<h1>Trang giới thiệu</h1>


<table class="table table-bordered">
    <thead>
      <tr>
        <th></th>
        <th>Thứ 2</th>
        <th>Thứ 3</th>
		<th>Thứ 4</th>
		<th>Thứ 5</th>
		<th>Thứ 6</th>
		<th>Thứ 7</th>
		<th>Chủ nhật</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Ca 1</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
      </tr>
      <tr>
	  	<td>Ca 2</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
      </tr>
      <tr>
     	<td>Ca 3</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
      </tr>
	  <tr>
     	<td>Ca 4</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
      </tr>
	  <tr>
     	<td>Ca 5</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
      </tr>
	  <tr>
     	<td>Ca 6</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
      </tr>
    </tbody>
  </table>