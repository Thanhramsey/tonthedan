<aside class="main-sidebar">

	<section class="sidebar">
		<ul class="sidebar-menu">
			<li class="treeview">
				<a href="<?php echo base_url() ?>admin">
					<i class="fa fa-bar-chart"></i> <span>Thống kê</span>
				</a>
			</li>
			<li class="header">QUẢN LÝ CỬA HÀNG</li>
			<li class="treeview">
				<a href="<?php echo base_url() ?>admin/content">
					<i class="glyphicon glyphicon-list"></i><span>Tin tức</span>
				</a>
			</li>
			<li class="treeview">
				<a href="<?php echo base_url() ?>admin/contact">
					<i class="fa fa-envelope"></i> <span>Liên hệ</span>
				</a>
			</li>
			<li class="treeview">
				<a href="<?php echo base_url() ?>admin/sliders">
					<i class="glyphicon glyphicon-tree-deciduous"></i><span>Sản phẩm</span>
				</a>
			</li>
			<li class="treeview">
				<a href="admin/configuration/update">
					<i class="glyphicon glyphicon-cog"></i><span> Cấu hình</span>
				</a>
			</li>
			<li><a href="admin/user/logout.html"><i class="fa fa-sign-out text-red"></i> <span>Thoát</span></a></li>
		</ul>
	</section>
	<!-- /.sidebar -->
</aside>